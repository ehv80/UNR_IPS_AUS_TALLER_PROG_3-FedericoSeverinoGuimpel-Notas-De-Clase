
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import java.awt.ComponentOrientation;
import java.awt.Dimension;

import javax.swing.JInternalFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JDesktopPane;
import javax.swing.SwingConstants;

/**
 * @author ehv80
 *
 */
public class JABM extends JFrame {

	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;

	private JPanel jContentPaneABM = null;

	private JMenuBar jJMenuBarABM = null;

	private JMenu jMenuABM = null;

	private JMenuItem jMenuItemABMAltas = null;

	private JMenuItem jMenuItemABMBajas = null;

	private JMenuItem jMenuItemABMModificaciones = null;

	private JMenuItem jMenuItemABMSalir = null;

	private JDesktopPane jDesktopPaneABM = null;
	
	/**
	 * @throws HeadlessException
	 */
	public JABM() throws HeadlessException {
		// TODO Auto-generated constructor stub
		super();
		initialize();
	}

	/**
	 * @param gc
	 */
	public JABM(GraphicsConfiguration gc) {
		super(gc);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @throws HeadlessException
	 */
	public JABM(String title) throws HeadlessException {
		super(title);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param gc
	 */
	public JABM(String title, GraphicsConfiguration gc) {
		super(title, gc);
		// TODO Auto-generated constructor stub
		initialize();
	}
		
	/**
	 * This method initializes jJMenuBarABM	
	 * 	
	 * @return javax.swing.JMenuBar	
	 **/
	private JMenuBar getJJMenuBarABM() {
		if (jJMenuBarABM == null) {
			jJMenuBarABM = new JMenuBar();
			jJMenuBarABM.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
			jJMenuBarABM.add(getJMenuABM());
		}
		return jJMenuBarABM;
	}
	
	/**
	 * This method initializes jMenuABM	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenuABM() {
		if (jMenuABM == null) {
			jMenuABM = new JMenu();
			jMenuABM.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
			jMenuABM.setText("ACCIONES");
			jMenuABM.add(getJMenuItemABMAltas());
			jMenuABM.add(getJMenuItemABMBajas());
			jMenuABM.add(getJMenuItemABMModificaciones());
			jMenuABM.add(getJMenuItemABMSalir());
		}
		return jMenuABM;
	}

	/**
	 * This method initializes jMenuItemABMAltas	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemABMAltas() {
		if (jMenuItemABMAltas == null) {
			jMenuItemABMAltas = new JMenuItem();
			jMenuItemABMAltas.setText("Altas");
			jMenuItemABMAltas.setHorizontalAlignment(SwingConstants.LEADING);
			jMenuItemABMAltas.setHorizontalTextPosition(SwingConstants.TRAILING);
			jMenuItemABMAltas.setComponentOrientation(ComponentOrientation.UNKNOWN);
			jMenuItemABMAltas
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							//System.out.println("actionPerformed()");
							// TODO Auto-generated Event stub actionPerformed()
							JInternalFrame[] arregloJIF = jDesktopPaneABM.getAllFrames();
							boolean existeVentana = false;
							for(int i = 0 ; i < arregloJIF.length ; i++)
							{
								if( arregloJIF[i] instanceof JAltas){
									arregloJIF[i].toFront();
									existeVentana = true;
								}	
							}
							if(!existeVentana) {
								JAltas altas = new JAltas();
								jDesktopPaneABM.add(altas);
								altas.setVisible(true);
							}
						}
					});
		}
		return jMenuItemABMAltas;
	}

	/**
	 * This method initializes jMenuItemABMBajas	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemABMBajas() {
		if (jMenuItemABMBajas == null) {
			jMenuItemABMBajas = new JMenuItem();
			jMenuItemABMBajas.setText("Bajas");
			jMenuItemABMBajas.setComponentOrientation(ComponentOrientation.UNKNOWN);
			jMenuItemABMBajas
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							//System.out.println("actionPerformed()");
							// TODO Auto-generated Event stub actionPerformed()
							JInternalFrame[] arregloJIF = jDesktopPaneABM.getAllFrames();
							boolean existeVentana = false;
							for(int i = 0 ; i < arregloJIF.length ; i++)
							{
								if( arregloJIF[i] instanceof JBajas){
									arregloJIF[i].toFront();
									existeVentana = true;
								}	
							}
							if(!existeVentana) {
								JBajas bajas = new JBajas();
								jDesktopPaneABM.add(bajas);
								bajas.setVisible(true);
							}
						}
					});
		}
		return jMenuItemABMBajas;
	}

	/**
	 * This method initializes jMenuItemABMModificaciones	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemABMModificaciones() {
		if (jMenuItemABMModificaciones == null) {
			jMenuItemABMModificaciones = new JMenuItem();
			jMenuItemABMModificaciones.setText("Modificaciones");
			jMenuItemABMModificaciones.setComponentOrientation(ComponentOrientation.UNKNOWN);
			jMenuItemABMModificaciones
					.addActionListener(new java.awt.event.ActionListener() {   
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					//System.out.println("actionPerformed()");
					// TODO Auto-generated Event stub actionPerformed()
					JInternalFrame[] arregloJIF = jDesktopPaneABM.getAllFrames();
					boolean existeVentana = false;
					for(int i = 0 ; i < arregloJIF.length ; i++)
					{
						if( arregloJIF[i] instanceof JModificaciones){
							arregloJIF[i].toFront();
							existeVentana = true;
					}	
						}
					if(!existeVentana) {
						JModificaciones modificaciones = new JModificaciones();
						jDesktopPaneABM.add(modificaciones);
						modificaciones.setVisible(true);
						}
					}
				});
		}
		return jMenuItemABMModificaciones;
	}

	/**
	 * This method initializes jMenuItemABMSalir	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemABMSalir() {
		if (jMenuItemABMSalir == null) {
			jMenuItemABMSalir = new JMenuItem();
			jMenuItemABMSalir.setText("Salir");
			jMenuItemABMSalir.setComponentOrientation(ComponentOrientation.UNKNOWN);
			jMenuItemABMSalir
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							//System.out.println("actionPerformed()");
							// TODO Auto-generated Event stub actionPerformed()
							
							dispose();
						}
					});
		}
		return jMenuItemABMSalir;
	}

	/**
	 * This method initializes jDesktopPaneABM	
	 * 	
	 * @return javax.swing.JDesktopPane	
	 */
	private JDesktopPane getJDesktopPaneABM() {
		if (jDesktopPaneABM == null) {
			jDesktopPaneABM = new JDesktopPane();
			jDesktopPaneABM.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
			jDesktopPaneABM.setPreferredSize(new Dimension(200, 100));
		}
		return jDesktopPaneABM;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JABM thisClass = new JABM();
				thisClass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				thisClass.setVisible(true);
			}
		});
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(400, 300);
		this.setPreferredSize(new Dimension(400, 300));
		this.setJMenuBar(getJJMenuBarABM());
		this.setContentPane(getJContentPaneABM());
		this.setTitle("HIBERNATE ABM");
	}

	/**
	 * This method initializes jContentPaneABM
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPaneABM() {
		if (jContentPaneABM == null) {
			jContentPaneABM = new JPanel();
			jContentPaneABM.setLayout(new BorderLayout());
			jContentPaneABM.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
			jContentPaneABM.setPreferredSize(new Dimension(200, 100));
			jContentPaneABM.add(getJDesktopPaneABM(), BorderLayout.CENTER);
		}
		return jContentPaneABM;
	}

}
