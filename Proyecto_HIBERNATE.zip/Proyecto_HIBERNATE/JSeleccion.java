
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.Dimension;

/**
 * @author ehv80
 *
 */
public class JSeleccion extends JInternalFrame {

	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	private JPanel jContentPaneSeleccion = null;
	private JScrollPane jScrollPaneSeleccion = null;
	private JTable jTableSeleccion = null;
	private JButton jButtonSeleccionSalir = null;
	
	private JResultadoConsulta resultadoConsulta = null;  //  @jve:decl-index=0:
	private JModificaciones modificaciones;
	private JBajas bajas;

	/**
	 * 
	 */
	public JSeleccion() {
		// TODO Auto-generated constructor stub
		super();
		initialize();
	}

	/**
	 * @param title
	 */
	public JSeleccion(String title) {
		super(title);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 */
	public JSeleccion(String title, boolean resizable) {
		super(title, resizable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 * @param closable
	 */
	public JSeleccion(String title, boolean resizable,
			boolean closable) {
		super(title, resizable, closable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 * @param closable
	 * @param maximizable
	 */
	public JSeleccion(String title, boolean resizable,
			boolean closable, boolean maximizable) {
		super(title, resizable, closable, maximizable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 * @param closable
	 * @param maximizable
	 * @param iconifiable
	 */
	public JSeleccion(String title, boolean resizable,
			boolean closable, boolean maximizable, boolean iconifiable) {
		super(title, resizable, closable, maximizable, iconifiable);
		// TODO Auto-generated constructor stub
		initialize();
	}
	
	 /** Constructor adicional:
     * @param JResultadoConsulta resultadoConsulta
     * @param JModficaciones modificaciones
     */
    public JSeleccion(JResultadoConsulta resultadoConsulta, JModificaciones modificaciones)
    {
            super();
            initialize();
            this.resultadoConsulta = resultadoConsulta;
            this.modificaciones = modificaciones;
            jTableSeleccion = resultadoConsulta.getTabla();
            jTableSeleccion.addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseClicked( java.awt.event.MouseEvent e) {
                            getModificaciones().cargaDatos(getResultadoConsulta().getFila(jTableSeleccion.getSelectedRow()));
                            setVisible(false);
                            }
                    });
            jScrollPaneSeleccion.setViewportView(jTableSeleccion);
    }

	
	
    /** Constructor adicional:
     * @param JResultadoconsulta resultadoConsulta
     * @param JBajas bajas
     */
    public JSeleccion(JResultadoConsulta resultadoConsulta, JBajas bajas){
            super();
            initialize();
            this.resultadoConsulta = resultadoConsulta;
            this.bajas = bajas;
            jTableSeleccion = resultadoConsulta.getTabla();
            jTableSeleccion.addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseClicked(java.awt.event.MouseEvent e) {
                            getBajas().cargaDatos(getResultadoConsulta().getFila(jTableSeleccion.getSelectedRow()));
                            setVisible(false);
                    }
            });
            jScrollPaneSeleccion.setViewportView(jTableSeleccion);
    }
    /** Método: getModificaciones
     * @param void
     * @return JBajas bajas
     */
	public JBajas getBajas() {
		// TODO Auto-generated method stub
		return this.bajas;
	}

	/** Método: getModificaciones
     * @param void
     * @return JModificaciones modificaciones
     */
    public JModificaciones getModificaciones() {
            return this.modificaciones;
    }

	/**
	 * @param List<Abm>
	 * @return void
	 */
	public void setResultadoConsulta(JResultadoConsulta otraListaDeAbms )
	{
		this.resultadoConsulta = otraListaDeAbms;
	}
	
	/**
	 * @param void
	 * @return List<Abm>
	 */
	public JResultadoConsulta getResultadoConsulta()
	{
		return this.resultadoConsulta;
	}

	/**
	 * This method initializes jScrollPaneSeleccion	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPaneSeleccion() {
		if (jScrollPaneSeleccion == null) {
			jScrollPaneSeleccion = new JScrollPane();
			jScrollPaneSeleccion.setViewportView(getJTableSeleccion());
		}
		return jScrollPaneSeleccion;
	}

	/**
	 * This method initializes jTableSeleccion	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getJTableSeleccion() {
		if (jTableSeleccion == null) {
			jTableSeleccion = new JTable();
		}
		return jTableSeleccion;
	}

	/**
	 * This method initializes jButtonSeleccionSalir	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonSeleccionSalir() {
		if (jButtonSeleccionSalir == null) {
			jButtonSeleccionSalir = new JButton();
			jButtonSeleccionSalir.setText("SALIR");
			jButtonSeleccionSalir
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							//System.out.println("actionPerformed()");
							// TODO Auto-generated Event stub actionPerformed()
							if(HibernateUtil.getSession() != null && HibernateUtil.getSession() != null)
							{
								HibernateUtil.desconectar();
							}
							dispose();
						}
					});
		}
		return jButtonSeleccionSalir;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 200);
		this.setPreferredSize(new Dimension(300, 200));
		this.setResizable(true);
		this.setMaximizable(true);
		this.setClosable(true);
		this.setTitle("BUSCA CON HIBERNATE");
		this.setContentPane(getJContentPaneSeleccion());
	}

	/**
	 * This method initializes jContentPaneSeleccion
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPaneSeleccion() {
		if (jContentPaneSeleccion == null) {
			jContentPaneSeleccion = new JPanel();
			jContentPaneSeleccion.setLayout(new BorderLayout());
			jContentPaneSeleccion.add(getJScrollPaneSeleccion(), BorderLayout.CENTER);
			jContentPaneSeleccion.add(getJButtonSeleccionSalir(), BorderLayout.SOUTH);
		}
		return jContentPaneSeleccion;
	}

}
