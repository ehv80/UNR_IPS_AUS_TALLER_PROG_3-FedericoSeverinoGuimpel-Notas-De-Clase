import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JInternalFrame;
import javax.swing.BorderFactory;
import javax.swing.border.EtchedBorder;
import javax.swing.JDesktopPane;
import java.awt.Dimension;
import java.awt.Point;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;

/**
 * @author ehv80
 *
 */
public class JModificaciones extends JInternalFrame {

	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	private JPanel jContentPaneModificaciones = null;
	private JDesktopPane jDesktopPaneModificaciones = null;
	private JLabel jLabelModificacionesNombre = null;
	private JLabel jLabelModificacionesApellido = null;
	private JComboBox jComboBoxModificacionesTipoDocumento = null;
	private JLabel jLabelModificacionesEdad = null;
	private JTextField jTextFieldModificacionesNombre = null;
	private JTextField jTextFieldModificacionesApellido = null;
	private JTextField jTextFieldModificacionesDocumento = null;
	private JTextField jTextFieldModificacionesEdad = null;
	private JButton jButtonModificacionesGrabar = null;
	private JButton jButtonModificacionesBuscar = null;
	private JButton jButtonModificacionesSalir = null;
	/**
	 * 
	 */
	public JModificaciones() {
		// TODO Auto-generated constructor stub
		super();
		initialize();
	}

	/**
	 * @param title
	 */
	public JModificaciones(String title) {
		super(title);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 */
	public JModificaciones(String title, boolean resizable) {
		super(title, resizable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 * @param closable
	 */
	public JModificaciones(String title, boolean resizable,
			boolean closable) {
		super(title, resizable, closable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 * @param closable
	 * @param maximizable
	 */
	public JModificaciones(String title, boolean resizable,
			boolean closable, boolean maximizable) {
		super(title, resizable, closable, maximizable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 * @param closable
	 * @param maximizable
	 * @param iconifiable
	 */
	public JModificaciones(String title, boolean resizable,
			boolean closable, boolean maximizable, boolean iconifiable) {
		super(title, resizable, closable, maximizable, iconifiable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	 /**
     * Método: cargaDatos
     *
     * @param Vector <String> datos
     * @return void
     */
    public void cargaDatos(Vector <String> datos) {
            setVisible(true);
            
            // Orden según Abm.hbm.xml
            
            //jTextFieldModificacionesNombre.setText(datos.get(0));
            jTextFieldModificacionesDocumento.setText(datos.get(0));
            
            //jTextFieldModificacionesApellido.setText(datos.get(1));
            jTextFieldModificacionesNombre.setText(datos.get(1));
            
            //jComboBoxModificacionesTipoDocumento.setSelectedItem(datos.get(2));
            jTextFieldModificacionesApellido.setText(datos.get(2));
            
            //jTextFieldModificacionesDocumento.setText(datos.get(3));
            jComboBoxModificacionesTipoDocumento.setSelectedItem(datos.get(3));
            
            jTextFieldModificacionesEdad.setText(datos.get(4));
    }
	
	/**
	 * This method initializes jDesktopPaneModificaciones	
	 * 	
	 * @return javax.swing.JDesktopPane	
	 */
	private JDesktopPane getJDesktopPaneModificaciones() {
		if (jDesktopPaneModificaciones == null) {
			jLabelModificacionesEdad = new JLabel();
			jLabelModificacionesEdad.setText("EDAD");
			jLabelModificacionesEdad.setLocation(new Point(25, 105));
			jLabelModificacionesEdad.setHorizontalAlignment(SwingConstants.CENTER);
			jLabelModificacionesEdad.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabelModificacionesEdad.setPreferredSize(new Dimension(80, 20));
			jLabelModificacionesEdad.setSize(new Dimension(80, 20));
			jLabelModificacionesApellido = new JLabel();
			jLabelModificacionesApellido.setText("APELLIDO");
			jLabelModificacionesApellido.setSize(new Dimension(80, 20));
			jLabelModificacionesApellido.setPreferredSize(new Dimension(80, 20));
			jLabelModificacionesApellido.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabelModificacionesApellido.setHorizontalAlignment(SwingConstants.CENTER);
			jLabelModificacionesApellido.setLocation(new Point(25, 45));
			jLabelModificacionesNombre = new JLabel();
			jLabelModificacionesNombre.setText("NOMBRE");
			jLabelModificacionesNombre.setLocation(new Point(25, 15));
			jLabelModificacionesNombre.setPreferredSize(new Dimension(80, 20));
			jLabelModificacionesNombre.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabelModificacionesNombre.setHorizontalAlignment(SwingConstants.CENTER);
			jLabelModificacionesNombre.setSize(new Dimension(80, 20));
			jDesktopPaneModificaciones = new JDesktopPane();
			jDesktopPaneModificaciones.add(jLabelModificacionesNombre, null);
			jDesktopPaneModificaciones.add(jLabelModificacionesApellido, null);
			jDesktopPaneModificaciones.add(getJComboBoxModificacionesTipoDocumento(), null);
			jDesktopPaneModificaciones.add(jLabelModificacionesEdad, null);
			jDesktopPaneModificaciones.add(getJTextFieldModificacionesNombre(), null);
			jDesktopPaneModificaciones.add(getJTextFieldModificacionesApellido(), null);
			jDesktopPaneModificaciones.add(getJTextFieldModificacionesDocumento(), null);
			jDesktopPaneModificaciones.add(getJTextFieldModificacionesEdad(), null);
			jDesktopPaneModificaciones.add(getJButtonModificacionesGrabar(), null);
			jDesktopPaneModificaciones.add(getJButtonModificacionesBuscar(), null);
			jDesktopPaneModificaciones.add(getJButtonModificacionesSalir(), null);
		}
		return jDesktopPaneModificaciones;
	}

	/**
	 * This method initializes jComboBoxModificacionesTipoDocumento	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBoxModificacionesTipoDocumento() {
		if (jComboBoxModificacionesTipoDocumento == null) {
			jComboBoxModificacionesTipoDocumento = new JComboBox();
			jComboBoxModificacionesTipoDocumento.setSize(new Dimension(80, 20));
			jComboBoxModificacionesTipoDocumento.setPreferredSize(new Dimension(80, 20));
			jComboBoxModificacionesTipoDocumento.setLocation(new Point(25, 75));
			jComboBoxModificacionesTipoDocumento.addItem("DNI");
			jComboBoxModificacionesTipoDocumento.addItem("LC");
			jComboBoxModificacionesTipoDocumento.addItem("LE");
		}
		return jComboBoxModificacionesTipoDocumento;
	}

	/**
	 * This method initializes jTextFieldModificacionesNombre	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldModificacionesNombre() {
		if (jTextFieldModificacionesNombre == null) {
			jTextFieldModificacionesNombre = new JTextField();
			jTextFieldModificacionesNombre.setLocation(new Point(115, 15));
			jTextFieldModificacionesNombre.setPreferredSize(new Dimension(140, 20));
			jTextFieldModificacionesNombre.setSize(new Dimension(140, 20));
		}
		return jTextFieldModificacionesNombre;
	}

	/**
	 * This method initializes jTextFieldModificacionesApellido	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldModificacionesApellido() {
		if (jTextFieldModificacionesApellido == null) {
			jTextFieldModificacionesApellido = new JTextField();
			jTextFieldModificacionesApellido.setSize(new Dimension(140, 20));
			jTextFieldModificacionesApellido.setPreferredSize(new Dimension(140, 20));
			jTextFieldModificacionesApellido.setLocation(new Point(115, 45));
		}
		return jTextFieldModificacionesApellido;
	}

	/**
	 * This method initializes jTextFieldModificacionesDocumento	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldModificacionesDocumento() {
		if (jTextFieldModificacionesDocumento == null) {
			jTextFieldModificacionesDocumento = new JTextField();
			jTextFieldModificacionesDocumento.setSize(new Dimension(140, 20));
			jTextFieldModificacionesDocumento.setPreferredSize(new Dimension(140, 20));
			jTextFieldModificacionesDocumento.setLocation(new Point(115, 75));
		}
		return jTextFieldModificacionesDocumento;
	}

	/**
	 * This method initializes jTextFieldModificacionesEdad	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldModificacionesEdad() {
		if (jTextFieldModificacionesEdad == null) {
			jTextFieldModificacionesEdad = new JTextField();
			jTextFieldModificacionesEdad.setSize(new Dimension(140, 20));
			jTextFieldModificacionesEdad.setPreferredSize(new Dimension(140, 20));
			jTextFieldModificacionesEdad.setLocation(new Point(115, 105));
		}
		return jTextFieldModificacionesEdad;
	}

	/**
	 * This method initializes jButtonModificacionesGrabar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonModificacionesGrabar() {
		if (jButtonModificacionesGrabar == null) {
			jButtonModificacionesGrabar = new JButton();
			jButtonModificacionesGrabar.setText("GRABAR");
			jButtonModificacionesGrabar.setSize(new Dimension(90, 20));
			jButtonModificacionesGrabar.setHorizontalTextPosition(SwingConstants.CENTER);
			jButtonModificacionesGrabar.setLocation(new Point(2, 135));
			jButtonModificacionesGrabar
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							//System.out.println("actionPerformed()");
							// TODO Auto-generated Event stub actionPerformed()
							if(jTextFieldModificacionesNombre.getText().equals("") ||
									jTextFieldModificacionesApellido.getText().equals("") ||
									( (String)( jComboBoxModificacionesTipoDocumento.getSelectedItem() ) ).equals("") ||
									jTextFieldModificacionesDocumento.getText().equals("") || 
									jTextFieldModificacionesEdad.getText().equals("")
								)
							{
								JOptionPane.showMessageDialog(
										new JFrame(), 
										"Asegúrese de introducir todos los datos correctamente, o presione en \"BUSCAR\"..!",
										"ADVERTENCIA..!",
										JOptionPane.INFORMATION_MESSAGE
									);
							}
							else
							{
								Abm abmModificable;
								try
								{
									HibernateUtil.conectar(); //?
									abmModificable = new Abm(
											Integer.parseInt(jTextFieldModificacionesDocumento.getText()) ,
											jTextFieldModificacionesNombre.getText() ,
											jTextFieldModificacionesApellido.getText() ,
											(String)( jComboBoxModificacionesTipoDocumento.getSelectedItem() ) ,
											Short.parseShort( jTextFieldModificacionesEdad.getText() )
										);
									HibernateUtil.actualizarAbm(abmModificable);
								}
								catch(Exception ex)
								{
									System.err.println("Ha ocurrido una Excepción al actualizar un objeto Abm " + ex);
									JOptionPane.showMessageDialog(
											new JFrame(), 
											"Error al actualizar la información de la Base de Datos...!",
											"Advertencia...!", 
											JOptionPane.ERROR_MESSAGE
										);
								}
								finally
								{
									jTextFieldModificacionesNombre.setText("");
									jTextFieldModificacionesApellido.setText("");
									jTextFieldModificacionesDocumento.setText("");
									jTextFieldModificacionesEdad.setText("");
									abmModificable = null;
								}
							}
							
							
						}
					});
		}
		return jButtonModificacionesGrabar;
	}

	/**
	 * This method initializes jButtonModificacionesBuscar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonModificacionesBuscar() {
		if (jButtonModificacionesBuscar == null) {
			jButtonModificacionesBuscar = new JButton();
			jButtonModificacionesBuscar.setHorizontalTextPosition(SwingConstants.CENTER);
			jButtonModificacionesBuscar.setLocation(new Point(97, 135));
			jButtonModificacionesBuscar.setPreferredSize(new Dimension(90, 20));
			jButtonModificacionesBuscar.setText("BUSCAR");
			jButtonModificacionesBuscar.setSize(new Dimension(90, 20));
			jButtonModificacionesBuscar
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							//System.out.println("actionPerformed()");
							// TODO Auto-generated Event stub actionPerformed()
							
							String sentenciaHQL = "select p from Abm as p where 1=1 ";
							if( !jTextFieldModificacionesNombre.getText().equals("") )
								sentenciaHQL += " and p.nombre='" + jTextFieldModificacionesNombre.getText() + "' ";
							if( !jTextFieldModificacionesApellido.getText().equals("") )
								sentenciaHQL += " and p.apellido='" + jTextFieldModificacionesApellido.getText() + "' ";
							if( !jTextFieldModificacionesDocumento.getText().equals("") )
								sentenciaHQL += " and p.ndoc='" + jTextFieldModificacionesDocumento.getText() + "' ";
							if( !jTextFieldModificacionesEdad.getText().equals("") )
								sentenciaHQL += " and p.edad='" + jTextFieldModificacionesEdad.getText() + "' ";
							//?
							JResultadoConsulta resultadoConsulta;
							JSeleccion ventanaSeleccion;
							try
							{
								HibernateUtil.conectar();
								resultadoConsulta = HibernateUtil.consulta(sentenciaHQL);
								ventanaSeleccion = new JSeleccion(resultadoConsulta, getEstaVentana() );
								jDesktopPaneModificaciones.add(ventanaSeleccion);
								ventanaSeleccion.setVisible(true); 
								//HibernateUtil.desconectar(); //?
								//setVisible(true);
							}
							catch(Exception ex)
							{
								System.err.println("Ha ocurrido una Excepción al obtener la información desde la Base de Datos " + ex);
								JOptionPane.showMessageDialog(
										new JFrame(),
										"Error al obtener la información de la Base de Datos..!", 
										"ADVERTENCIA..!", 
										JOptionPane.ERROR_MESSAGE
									);
							}
							finally
							{
								//TODO
							}
							
						}
					});
		}
		return jButtonModificacionesBuscar;
	}

	public JModificaciones getEstaVentana() {
		// TODO Auto-generated method stub
		return this;
	}

	/**
	 * This method initializes jButtonModificacionesSalir	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonModificacionesSalir() {
		if (jButtonModificacionesSalir == null) {
			jButtonModificacionesSalir = new JButton();
			jButtonModificacionesSalir.setSize(new Dimension(90, 20));
			jButtonModificacionesSalir.setText("SALIR");
			jButtonModificacionesSalir.setLocation(new Point(193, 135));
			jButtonModificacionesSalir
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							//System.out.println("actionPerformed()");
							// TODO Auto-generated Event stub actionPerformed()
							if( HibernateUtil.getSession() != null && HibernateUtil.getSessionFactory() != null )
							{
								HibernateUtil.desconectar();
							}
							dispose();
						}
					});
		}
		return jButtonModificacionesSalir;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 200);
		this.setClosable(true);
		this.setMaximizable(true);
		this.setResizable(true);
		this.setTitle("HIBERNATE MODIFICACIONES");
		this.setContentPane(getJContentPaneModificaciones());
	}

	/**
	 * This method initializes jContentPaneModificaciones
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPaneModificaciones() {
		if (jContentPaneModificaciones == null) {
			jContentPaneModificaciones = new JPanel();
			jContentPaneModificaciones.setLayout(new BorderLayout());
			jContentPaneModificaciones.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
			jContentPaneModificaciones.add(getJDesktopPaneModificaciones(), BorderLayout.CENTER);
		}
		return jContentPaneModificaciones;
	}

}
