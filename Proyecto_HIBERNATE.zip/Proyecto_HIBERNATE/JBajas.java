import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JInternalFrame;
import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import java.awt.Dimension;
import java.awt.Point;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.BorderFactory;
import javax.swing.border.EtchedBorder;

/**
 * @author ehv80
 *
 */
public class JBajas extends JInternalFrame {

	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	private JPanel jContentPaneBajas = null;
	private JDesktopPane jDesktopPaneBajas = null;
	private JLabel jLabelBajasNombre = null;
	private JLabel jLabelBajasApellido = null;
	private JComboBox jComboBoxBajasTipoDocumento = null;
	private JLabel jLabelBajasEdad = null;
	private JTextField jTextFieldBajasNombre = null;
	private JTextField jTextFieldBajasApellido = null;
	private JTextField jTextFieldBajasDocumento = null;
	private JTextField jTextFieldBajasEdad = null;
	private JButton jButtonBajasBorrar = null;
	private JButton jButtonBajasBuscar = null;
	private JButton jButtonBajasSalir = null;

	/**
	 * 
	 */
	public JBajas() {
		// TODO Auto-generated constructor stub
		super();
		initialize();
	}

	/**
	 * @param title
	 */
	public JBajas(String title) {
		super(title);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 */
	public JBajas(String title, boolean resizable) {
		super(title, resizable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 * @param closable
	 */
	public JBajas(String title, boolean resizable,
			boolean closable) {
		super(title, resizable, closable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 * @param closable
	 * @param maximizable
	 */
	public JBajas(String title, boolean resizable,
			boolean closable, boolean maximizable) {
		super(title, resizable, closable, maximizable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 * @param closable
	 * @param maximizable
	 * @param iconifiable
	 */
	public JBajas(String title, boolean resizable,
			boolean closable, boolean maximizable, boolean iconifiable) {
		super(title, resizable, closable, maximizable, iconifiable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/** Método:     cargaDatos
     * Toma los datos que están almacenados temporalmente
     * en el Vector de String "datos" y los introduce e los
     * campos de texto correspondientes de la interface del
     * objeto instancia de la clase visual JBajas.java.
     *
     * @param Vector <String> datos
     * @return void
     */
    public void cargaDatos(Vector <String> datos){
            setVisible(true);
            //El órden está dado por Abm.hbm.xml
            
            //jTextFieldBajasNombre.setText(datos.get(0));
            jTextFieldBajasDocumento.setText(datos.get(0));
            
            //jTextFieldBajasApellido.setText(datos.get(1));
            jTextFieldBajasNombre.setText(datos.get(1));
            
            //jComboBoxBajasTipoDocumento.setSelectedItem(datos.get(2));
            jTextFieldBajasApellido.setText(datos.get(2));
            
            //jTextFieldBajasDocumento.setText(datos.get(3));
            jComboBoxBajasTipoDocumento.setSelectedItem(datos.get(3));
            
            jTextFieldBajasEdad.setText(datos.get(4));
            
    }
	
	/**
	 * This method initializes jDesktopPaneBajas	
	 * 	
	 * @return javax.swing.JDesktopPane	
	 */
	private JDesktopPane getJDesktopPaneBajas() {
		if (jDesktopPaneBajas == null) {
			jLabelBajasEdad = new JLabel();
			jLabelBajasEdad.setText("EDAD");
			jLabelBajasEdad.setLocation(new Point(25, 105));
			jLabelBajasEdad.setPreferredSize(new Dimension(80, 20));
			jLabelBajasEdad.setHorizontalAlignment(SwingConstants.CENTER);
			jLabelBajasEdad.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabelBajasEdad.setSize(new Dimension(80, 20));
			jLabelBajasApellido = new JLabel();
			jLabelBajasApellido.setText("APELLIDO");
			jLabelBajasApellido.setLocation(new Point(25, 45));
			jLabelBajasApellido.setPreferredSize(new Dimension(80, 20));
			jLabelBajasApellido.setHorizontalAlignment(SwingConstants.CENTER);
			jLabelBajasApellido.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabelBajasApellido.setSize(new Dimension(80, 20));
			jLabelBajasNombre = new JLabel();
			jLabelBajasNombre.setText("NOMBRE");
			jLabelBajasNombre.setLocation(new Point(25, 15));
			jLabelBajasNombre.setHorizontalAlignment(SwingConstants.CENTER);
			jLabelBajasNombre.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabelBajasNombre.setPreferredSize(new Dimension(80, 20));
			jLabelBajasNombre.setSize(new Dimension(80, 20));
			jDesktopPaneBajas = new JDesktopPane();
			jDesktopPaneBajas.add(jLabelBajasNombre, null);
			jDesktopPaneBajas.add(jLabelBajasApellido, null);
			jDesktopPaneBajas.add(getJComboBoxBajasTipoDocumento(), null);
			jDesktopPaneBajas.add(jLabelBajasEdad, null);
			jDesktopPaneBajas.add(getJTextFieldBajasNombre(), null);
			jDesktopPaneBajas.add(getJTextFieldBajasApellido(), null);
			jDesktopPaneBajas.add(getJTextFieldBajasDocumento(), null);
			jDesktopPaneBajas.add(getJTextFieldBajasEdad(), null);
			jDesktopPaneBajas.add(getJButtonBajasBorrar(), null);
			jDesktopPaneBajas.add(getJButtonBajasBuscar(), null);
			jDesktopPaneBajas.add(getJButtonBajasSalir(), null);
		}
		return jDesktopPaneBajas;
	}

	/**
	 * This method initializes jComboBoxBajasTipoDocumento	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBoxBajasTipoDocumento() {
		if (jComboBoxBajasTipoDocumento == null) {
			jComboBoxBajasTipoDocumento = new JComboBox();
			jComboBoxBajasTipoDocumento.setSize(new Dimension(80, 20));
			jComboBoxBajasTipoDocumento.setLocation(new Point(25, 75));
			jComboBoxBajasTipoDocumento.addItem("DNI");
			jComboBoxBajasTipoDocumento.addItem("LC");
			jComboBoxBajasTipoDocumento.addItem("LE");
		}
		return jComboBoxBajasTipoDocumento;
	}

	/**
	 * This method initializes jTextFieldBajasNombre	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldBajasNombre() {
		if (jTextFieldBajasNombre == null) {
			jTextFieldBajasNombre = new JTextField();
			jTextFieldBajasNombre.setSize(new Dimension(140, 20));
			jTextFieldBajasNombre.setLocation(new Point(115, 15));
		}
		return jTextFieldBajasNombre;
	}

	/**
	 * This method initializes jTextFieldBajasApellido	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldBajasApellido() {
		if (jTextFieldBajasApellido == null) {
			jTextFieldBajasApellido = new JTextField();
			jTextFieldBajasApellido.setSize(new Dimension(140, 20));
			jTextFieldBajasApellido.setPreferredSize(new Dimension(140, 20));
			jTextFieldBajasApellido.setLocation(new Point(115, 45));
		}
		return jTextFieldBajasApellido;
	}

	/**
	 * This method initializes jTextFieldBajasDocumento	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldBajasDocumento() {
		if (jTextFieldBajasDocumento == null) {
			jTextFieldBajasDocumento = new JTextField();
			jTextFieldBajasDocumento.setSize(new Dimension(140, 20));
			jTextFieldBajasDocumento.setLocation(new Point(115, 75));
		}
		return jTextFieldBajasDocumento;
	}

	/**
	 * This method initializes jTextFieldBajasEdad	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldBajasEdad() {
		if (jTextFieldBajasEdad == null) {
			jTextFieldBajasEdad = new JTextField();
			jTextFieldBajasEdad.setSize(new Dimension(140, 20));
			jTextFieldBajasEdad.setPreferredSize(new Dimension(140, 20));
			jTextFieldBajasEdad.setLocation(new Point(115, 105));
		}
		return jTextFieldBajasEdad;
	}

	/**
	 * This method initializes jButtonBajasBorrar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonBajasBorrar() {
		if (jButtonBajasBorrar == null) {
			jButtonBajasBorrar = new JButton();
			jButtonBajasBorrar.setSize(new Dimension(90, 20));
			jButtonBajasBorrar.setPreferredSize(new Dimension(90, 20));
			jButtonBajasBorrar.setText("BORRAR");
			jButtonBajasBorrar.setHorizontalTextPosition(SwingConstants.CENTER);
			jButtonBajasBorrar.setLocation(new Point(2, 135));
			jButtonBajasBorrar
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							//System.out.println("actionPerformed()");
							// TODO Auto-generated Event stub actionPerformed()
							if(jTextFieldBajasNombre.getText().equals("") ||
									jTextFieldBajasApellido.getText().equals("") ||
									( (String)( jComboBoxBajasTipoDocumento.getSelectedItem() ) ).equals("") ||
									jTextFieldBajasDocumento.getText().equals("") || 
									jTextFieldBajasEdad.getText().equals("")
								)
							{
								JOptionPane.showMessageDialog(
										new JFrame(), 
										"Asegúrese de introducir todos los datos correctamente, o presione en \"BUSCAR\"..!",
										"ADVERTENCIA..!",
										JOptionPane.INFORMATION_MESSAGE
									);
							}
							else
							{
								Abm abmBaja;
								try
								{
									HibernateUtil.conectar(); //?
									abmBaja = new Abm(
											Integer.parseInt(jTextFieldBajasDocumento.getText()) ,
											jTextFieldBajasNombre.getText() ,
											jTextFieldBajasApellido.getText() ,
											(String)( jComboBoxBajasTipoDocumento.getSelectedItem() ) ,
											Short.parseShort( jTextFieldBajasEdad.getText() )
										);
									HibernateUtil.eliminarAbm(abmBaja);
								}
								catch(Exception ex)
								{
									System.err.println("Ha ocurrido una Excepción al eliminar un objeto Abm " + ex);
									JOptionPane.showMessageDialog(
											new JFrame(), 
											"Error al eliminar la información de la Base de Datos...!",
											"Advertencia...!", 
											JOptionPane.ERROR_MESSAGE
										);
								}
								finally
								{
									jTextFieldBajasNombre.setText("");
									jTextFieldBajasApellido.setText("");
									jTextFieldBajasDocumento.setText("");
									jTextFieldBajasEdad.setText("");
									abmBaja = null;
								}
							}
						}
					});
		}
		return jButtonBajasBorrar;
	}

	/**
	 * This method initializes jButtonBajasBuscar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonBajasBuscar() {
		if (jButtonBajasBuscar == null) {
			jButtonBajasBuscar = new JButton();
			jButtonBajasBuscar.setSize(new Dimension(90, 20));
			jButtonBajasBuscar.setHorizontalTextPosition(SwingConstants.CENTER);
			jButtonBajasBuscar.setText("BUSCAR");
			jButtonBajasBuscar.setLocation(new Point(97, 135));
			jButtonBajasBuscar
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							//System.out.println("actionPerformed()");
							// TODO Auto-generated Event stub actionPerformed()
							String sentenciaHQL = "select p from Abm as p where 1=1 ";
							if( !jTextFieldBajasNombre.getText().equals("") )
								sentenciaHQL += " and p.nombre='" + jTextFieldBajasNombre.getText() + "' ";
							if( !jTextFieldBajasApellido.getText().equals("") )
								sentenciaHQL += " and p.apellido='" + jTextFieldBajasApellido.getText() + "' ";
							if( !jTextFieldBajasDocumento.getText().equals("") )
								sentenciaHQL += " and p.ndoc='" + jTextFieldBajasDocumento.getText() + "' ";
							if( !jTextFieldBajasEdad.getText().equals("") )
								sentenciaHQL += " and p.edad='" + jTextFieldBajasEdad.getText() + "' ";
							//?
							JResultadoConsulta resultadoConsulta;
							JSeleccion ventanaSeleccion;
							try
							{
								HibernateUtil.conectar();
								resultadoConsulta = HibernateUtil.consulta(sentenciaHQL);
								ventanaSeleccion = new JSeleccion(resultadoConsulta, getEstaVentana() );
								jDesktopPaneBajas.add(ventanaSeleccion);
								ventanaSeleccion.setVisible(true); 
								//HibernateUtil.desconectar(); //?
								//setVisible(true);
							}
							catch(Exception ex)
							{
								System.err.println("Ha ocurrido una Excepción al obtener la información desde la Base de Datos " + ex);
								JOptionPane.showMessageDialog(
										new JFrame(),
										"Error al obtener la información de la Base de Datos..!", 
										"ADVERTENCIA..!", 
										JOptionPane.ERROR_MESSAGE
									);
							}
							finally
							{
								//TODO
							}
						}
					});
		}
		return jButtonBajasBuscar;
	}

	/**
	 * This method initializes jButtonBajasSalir	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonBajasSalir() {
		if (jButtonBajasSalir == null) {
			jButtonBajasSalir = new JButton();
			jButtonBajasSalir.setSize(new Dimension(90, 20));
			jButtonBajasSalir.setPreferredSize(new Dimension(90, 20));
			jButtonBajasSalir.setHorizontalTextPosition(SwingConstants.CENTER);
			jButtonBajasSalir.setText("SALIR");
			jButtonBajasSalir.setLocation(new Point(193, 135));
			jButtonBajasSalir
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							//System.out.println("actionPerformed()");
							// TODO Auto-generated Event stub actionPerformed()
							if( HibernateUtil.getSession() != null && HibernateUtil.getSessionFactory() != null )
							{
								HibernateUtil.desconectar();
							}
							dispose();
						}
					});
		}
		return jButtonBajasSalir;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 200);
		this.setMaximizable(true);
		this.setClosable(true);
		this.setResizable(true);
		this.setTitle("HIBERNATE BAJAS");
		this.setContentPane(getJContentPaneBajas());
	}

	/**
	 * This method initializes jContentPaneBajas
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPaneBajas() {
		if (jContentPaneBajas == null) {
			jContentPaneBajas = new JPanel();
			jContentPaneBajas.setLayout(new BorderLayout());
			jContentPaneBajas.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
			jContentPaneBajas.add(getJDesktopPaneBajas(), BorderLayout.CENTER);
		}
		return jContentPaneBajas;
	}
	
	/** 
	 * Retorna la Ventana Actual JBajas.
	 * @return JBajas
	 */
	public JBajas getEstaVentana(){
		return this;
	}

}
