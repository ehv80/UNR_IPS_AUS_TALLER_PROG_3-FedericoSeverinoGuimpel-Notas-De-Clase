/**
 * 
 */
//import java.sql.ResultSet;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;

/**
 * @author ehv80
 *
 */
public class JResultadoConsulta {

	/* ATRIBUTOS DE CLASE: static */
	
	/* ATRIBUTOS DE INSTANCIA */
	
	// Un Vector de Vector de String 
	// es como una matriz de String y redimensionable
	private Vector <Vector <String>> datos = null;
	//aquí tuve que cambiar el "project compliance" a 5.0
	
	private Vector <String> nombresColumnas = null;
	
	/* MÉTODO DE CLASE: static */
	
	/* MÉTODO DE INSTANCIA */
			
	/**
	 * Método: getFila
	 * Sirve para obtener una fila (Vector de String)
	 * del Vector de Vector de String: datos.
	 * Esto representa un registro de la Tabla de la Base de Datos.
	 * 
	 * @param int indice
	 * @return Vector <String>
	 */
	public Vector <String> getFila(int indice)
	{
		return datos.get(indice);
	}
	
	/**
	 * Constructor de la clase JResultadoConsulta
	 * 
	 * @param ResultSet conjuntoResultado
	 */
	public JResultadoConsulta(List<Abm> conjuntoResultado) {
		// TODO Auto-generated constructor stub
		//datos = JResultSetToVector.getDatos(conjuntoResultado);
		
		datos = new Vector <Vector <String>>();
		Field[] camposDeclarados;
		try 
		{
			for(Abm abm : conjuntoResultado )
			{
				Vector<String> temp = new Vector<String>();
					temp.add( String.valueOf( abm.getNdoc() ) );
					temp.add( abm.getNombre() );
					temp.add( abm.getApellido() );
					temp.add( abm.getTpdoc() );
					temp.add( String.valueOf( abm.getEdad() )); 
				//datos.add( abm.getDatos );
				datos.add( temp );
			}
			camposDeclarados = Abm.class.getDeclaredFields();
			//nombresColumnas = JResultSetToVector.getColumnas(conjuntoResultado);
			nombresColumnas = new Vector <String>();
			
			for(Field campo : camposDeclarados)
			{
				nombresColumnas.add(campo.getName());
			}
		}
		catch(Exception ex)
		{
			System.err.println("Ha ocurrido una Excepción al inicializar un objeto JResultadoConsulta " + ex);
			JOptionPane.showMessageDialog(
					new JFrame(),
					"Error al inicializar el conjunto resultado de la consulta...!",
					"ERROR INESPERADO...!",
					JOptionPane.ERROR_MESSAGE
				);
		}
		finally
		{
			//TODO
		}
	}

	/**
	 * Método: getTabla
	 * 
	 * Sirve para obtener una JTable con el Resueltado de la
	 * Consulta SQL. 
	 * 
	 * @return JTable
	 */
	public JTable getTabla()
	{
		return new JTable(datos, nombresColumnas);
	}
	
	public Abm getAbm(int i)
	{
		return new Abm(datos.get(i));
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
