
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JInternalFrame;
import javax.swing.BorderFactory;
import javax.swing.border.EtchedBorder;
import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import java.awt.Dimension;
import java.awt.Point;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;

/**
 * @author ehv80
 *
 */
public class JAltas extends JInternalFrame {

	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	private JPanel jContentPaneAltas = null;
	private JDesktopPane jDesktopPaneAltas = null;
	private JLabel jLabelAltasNombre = null;
	private JLabel jLabelAltasApellido = null;
	private JComboBox jComboBoxAltasTipoDocumento = null;
	private JLabel jLabelAltasEdad = null;
	private JTextField jTextFieldAltasNombre = null;
	private JTextField jTextFieldAltasApellido = null;
	private JTextField jTextFieldAltasDocumento = null;
	private JTextField jTextFieldAltasEdad = null;
	private JButton jButtonAltasGrabar = null;
	private JButton jButtonAltasSalir = null;

	/**
	 * 
	 */
	public JAltas() {
		// TODO Auto-generated constructor stub
		super();
		initialize();
	}

	/**
	 * @param title
	 */
	public JAltas(String title) {
		super(title);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 */
	public JAltas(String title, boolean resizable) {
		super(title, resizable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 * @param closable
	 */
	public JAltas(String title, boolean resizable,
			boolean closable) {
		super(title, resizable, closable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 * @param closable
	 * @param maximizable
	 */
	public JAltas(String title, boolean resizable,
			boolean closable, boolean maximizable) {
		super(title, resizable, closable, maximizable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * @param title
	 * @param resizable
	 * @param closable
	 * @param maximizable
	 * @param iconifiable
	 */
	public JAltas(String title, boolean resizable,
			boolean closable, boolean maximizable, boolean iconifiable) {
		super(title, resizable, closable, maximizable, iconifiable);
		// TODO Auto-generated constructor stub
		initialize();
	}

	/**
	 * This method initializes jDesktopPaneAltas	
	 * 	
	 * @return javax.swing.JDesktopPane	
	 */
	private JDesktopPane getJDesktopPaneAltas() {
		if (jDesktopPaneAltas == null) {
			jLabelAltasEdad = new JLabel();
			jLabelAltasEdad.setText("EDAD");
			jLabelAltasEdad.setLocation(new Point(25, 105));
			jLabelAltasEdad.setPreferredSize(new Dimension(80, 20));
			jLabelAltasEdad.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabelAltasEdad.setHorizontalAlignment(SwingConstants.CENTER);
			jLabelAltasEdad.setSize(new Dimension(80, 20));
			jLabelAltasApellido = new JLabel();
			jLabelAltasApellido.setHorizontalAlignment(SwingConstants.CENTER);
			jLabelAltasApellido.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabelAltasApellido.setSize(new Dimension(80, 20));
			jLabelAltasApellido.setLocation(new Point(25, 45));
			jLabelAltasApellido.setText("APELLIDO");
			jLabelAltasNombre = new JLabel();
			jLabelAltasNombre.setText("NOMBRE");
			jLabelAltasNombre.setLocation(new Point(25, 15));
			jLabelAltasNombre.setToolTipText("");
			jLabelAltasNombre.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabelAltasNombre.setHorizontalAlignment(SwingConstants.CENTER);
			jLabelAltasNombre.setPreferredSize(new Dimension(80, 20));
			jLabelAltasNombre.setSize(new Dimension(80, 20));
			jDesktopPaneAltas = new JDesktopPane();
			jDesktopPaneAltas.setPreferredSize(new Dimension(300, 200));
			jDesktopPaneAltas.add(jLabelAltasNombre, null);
			jDesktopPaneAltas.add(jLabelAltasApellido, null);
			jDesktopPaneAltas.add(getJComboBoxAltasTipoDocumento(), null);
			jDesktopPaneAltas.add(jLabelAltasEdad, null);
			jDesktopPaneAltas.add(getJTextFieldAltasNombre(), null);
			jDesktopPaneAltas.add(getJTextFieldAltasApellido(), null);
			jDesktopPaneAltas.add(getJTextFieldAltasDocumento(), null);
			jDesktopPaneAltas.add(getJTextFieldAltasEdad(), null);
			jDesktopPaneAltas.add(getJButtonAltasGrabar(), null);
			jDesktopPaneAltas.add(getJButtonAltasSalir(), null);
		}
		return jDesktopPaneAltas;
	}

	/**
	 * This method initializes jComboBoxAltasTipoDocumento	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBoxAltasTipoDocumento() {
		if (jComboBoxAltasTipoDocumento == null) {
			jComboBoxAltasTipoDocumento = new JComboBox();
			jComboBoxAltasTipoDocumento.setSize(new Dimension(80, 20));
			jComboBoxAltasTipoDocumento.setPreferredSize(new Dimension(80, 20));
			jComboBoxAltasTipoDocumento.setLocation(new Point(25, 75));
			jComboBoxAltasTipoDocumento.addItem("DNI");
			jComboBoxAltasTipoDocumento.addItem("LC");
			jComboBoxAltasTipoDocumento.addItem("LE");
		}
		return jComboBoxAltasTipoDocumento;
	}

	/**
	 * This method initializes jTextFieldAltasNombre	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldAltasNombre() {
		if (jTextFieldAltasNombre == null) {
			jTextFieldAltasNombre = new JTextField();
			jTextFieldAltasNombre.setSize(new Dimension(140, 20));
			jTextFieldAltasNombre.setPreferredSize(new Dimension(140, 20));
			jTextFieldAltasNombre.setToolTipText("Ingrese el Nombre...");
			jTextFieldAltasNombre.setLocation(new Point(115, 15));
		}
		return jTextFieldAltasNombre;
	}

	/**
	 * This method initializes jTextFieldAltasApellido	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldAltasApellido() {
		if (jTextFieldAltasApellido == null) {
			jTextFieldAltasApellido = new JTextField();
			jTextFieldAltasApellido.setSize(new Dimension(140, 20));
			jTextFieldAltasApellido.setPreferredSize(new Dimension(140, 20));
			jTextFieldAltasApellido.setToolTipText("Ingrese el Apellido...");
			jTextFieldAltasApellido.setLocation(new Point(115, 45));
		}
		return jTextFieldAltasApellido;
	}

	/**
	 * This method initializes jTextFieldAltasDocumento	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldAltasDocumento() {
		if (jTextFieldAltasDocumento == null) {
			jTextFieldAltasDocumento = new JTextField();
			jTextFieldAltasDocumento.setSize(new Dimension(140, 20));
			jTextFieldAltasDocumento.setPreferredSize(new Dimension(140, 20));
			jTextFieldAltasDocumento.setToolTipText("Introduzca el número de documento (sin puntos)...");
			jTextFieldAltasDocumento.setLocation(new Point(115, 75));
		}
		return jTextFieldAltasDocumento;
	}

	/**
	 * This method initializes jTextFieldAltasEdad	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldAltasEdad() {
		if (jTextFieldAltasEdad == null) {
			jTextFieldAltasEdad = new JTextField();
			jTextFieldAltasEdad.setSize(new Dimension(140, 20));
			jTextFieldAltasEdad.setPreferredSize(new Dimension(140, 20));
			jTextFieldAltasEdad.setToolTipText("Ingrese la edad...");
			jTextFieldAltasEdad.setLocation(new Point(115, 105));
		}
		return jTextFieldAltasEdad;
	}

	/**
	 * This method initializes jButtonAltasGrabar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonAltasGrabar() {
		if (jButtonAltasGrabar == null)
		{
			jButtonAltasGrabar = new JButton();
			jButtonAltasGrabar.setSize(new Dimension(90, 20));
			jButtonAltasGrabar.setPreferredSize(new Dimension(90, 20));
			jButtonAltasGrabar.setText("GRABAR");
			jButtonAltasGrabar.setHorizontalTextPosition(SwingConstants.CENTER);
			jButtonAltasGrabar.setLocation(new Point(2, 135));
			jButtonAltasGrabar
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							//System.out.println("actionPerformed()");
							// TODO Auto-generated Event stub actionPerformed()
							if(		jTextFieldAltasNombre.getText().equals("") ||
									jTextFieldAltasApellido.getText().equals("") ||
									jComboBoxAltasTipoDocumento.getSelectedItem().equals("") ||
									jTextFieldAltasDocumento.getText().equals("") ||
									jTextFieldAltasEdad.getText().equals("")
								)
							{
								JOptionPane.showMessageDialog (new JFrame(), 
										"Por favor verifique si ha ingresado correctamente todos los datos...", 
										"ADVERTENCIA..!", 
										JOptionPane.INFORMATION_MESSAGE	);
							}
							else
							{
								Abm abmAlta;
								try
								{
									abmAlta = new Abm(
											Integer.parseInt(jTextFieldAltasDocumento.getText()),
											jTextFieldAltasNombre.getText() ,
											jTextFieldAltasApellido.getText() ,
											(String)jComboBoxAltasTipoDocumento.getSelectedItem() ,
											Short.parseShort( jTextFieldAltasEdad.getText() )
											);
									HibernateUtil.conectar();//?
									HibernateUtil.guardarAbm(abmAlta);//?
									//HibernateUtil.desconectar();//?
									}
								catch(Exception ex)
								{
									System.err.println("Ha ocurrido una Excepción al instanciar un objeto Abm " + ex);
									JOptionPane.showMessageDialog(
											new JFrame(),
											"Un error muy extraño ha ocurrido... \nMejor, cierre la aplicación...!",
											"A la perinola... !!!",
											JOptionPane.INFORMATION_MESSAGE
											);
									}
								finally{
									//TODO
									jTextFieldAltasNombre.setText("");
									jTextFieldAltasApellido.setText("");
									jTextFieldAltasDocumento.setText("");
									jTextFieldAltasEdad.setText("");
									abmAlta = null;
									}
								}
							}
						});
			}
		return jButtonAltasGrabar;
	}

	/**
	 * This method initializes jButtonAltasSalir	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonAltasSalir() {
		if (jButtonAltasSalir == null) {
			jButtonAltasSalir = new JButton();
			jButtonAltasSalir.setSize(new Dimension(90, 20));
			jButtonAltasSalir.setHorizontalTextPosition(SwingConstants.CENTER);
			jButtonAltasSalir.setText("SALIR");
			jButtonAltasSalir.setPreferredSize(new Dimension(90, 20));
			jButtonAltasSalir.setLocation(new Point(193, 135));
			jButtonAltasSalir
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							//System.out.println("actionPerformed()");
							// TODO Auto-generated Event stub actionPerformed()
							if(HibernateUtil.getSession() != null && HibernateUtil.getSessionFactory() != null)
							{
								HibernateUtil.desconectar();//?
							}
							dispose();
						}
					});
		}
		return jButtonAltasSalir;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 200);
		this.setResizable(true);
		this.setMaximizable(true);
		this.setClosable(true);
		this.setTitle("HIBERNATE ALTAS");
		this.setContentPane(getJContentPaneAltas());
	}

	/**
	 * This method initializes jContentPaneAltas
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPaneAltas() {
		if (jContentPaneAltas == null) {
			jContentPaneAltas = new JPanel();
			jContentPaneAltas.setLayout(new BorderLayout());
			jContentPaneAltas.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
			jContentPaneAltas.setSize(new Dimension(300, 200));
			jContentPaneAltas.setPreferredSize(new Dimension(300, 200));
			jContentPaneAltas.add(getJDesktopPaneAltas(), BorderLayout.CENTER);
		}
		return jContentPaneAltas;
	}

}
